package com.itesm.pixelwars.Sprites.Animations;

public enum EstadoGuerrero {
    CAMINANDO, ATACANDO, QUIETO, MUERTO;
}
